const { Pool } = require('pg')

const pool = new Pool({
  user: 'siagaair',
  database: 'siagaair_v1',
  password: 'SiabIndonesia',
  host: 'localhost',
  port: 5432,
})

module.exports = pool
